from django.shortcuts import render
from django.contrib import messages
from django.utils.crypto import get_random_string


# Create your views here.ss
from django.shortcuts import render,redirect
from train.models import train_details
from train.models import login_details
from train.models import ticket_details
# Create your views here.

def index(request):
    return render(request,"main.html")

def showtrains(request):
    if request.method == "POST":
        from_station = request.POST.get('from_station')
        to_station = request.POST.get("to_station")
        date = request.POST.get("date")

    details = train_details.objects.filter(fromStnCode= from_station,toStnCode=to_station,date=date)
    count=len(details)
    print(details,len(details))
    return render(request,"result.html",{'details':details,'count':count})

def login(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')

    details = login_details.objects.filter(username = username,password=password)
    print(details)
    if details:
        return render(request, "main1.html", {'details': details})
    else:
        print('no user exist')
        messages.error(request, 'Invalid User!!! Please try logging in again with correct credentials')
        return redirect("/index/")




def register(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        phone_no = request.POST.get('phone_no')
        city = request.POST.get('city')
        state = request.POST.get('state')

    details = login_details(username=username,password=password,first_name=first_name,last_name=last_name,email=email,date_of_birth=date_of_birth,gender=gender,phone_no=phone_no,city=city,state=state)
    details.save()
    return redirect('/index')

def logout(request):
    return redirect('/index')


def forgot(request):
    return render(request, "For.html")

def change(request):
    if request.method == "POST":
        username = request.POST.get('username')
        phone_no = request.POST.get('phone_no')

    details = login_details.objects.filter(username = username,phone_no = phone_no)
    print(details)
    if details:
        return render(request, "for1.html", {'details': details})
    else:
        print('no user exist')
        messages.error(request, 'Invalid User!!! Please try again with correct credentials')
        return redirect("/forgot/")

def book(request):
    if request.method=="POST":
        username = request.POST.get('username')
        phone_no = request.POST.get('phone_no')
        from_stn = request.POST.get('from_stn')
        to_stn = request.POST.get('to_stn')
        date = request.POST.get('date')
        age = request.POST.get('age')

    pnr = get_random_string(length=6,allowed_chars='1234567890')
    details = ticket_details(name = username,phone_no=phone_no,fromStnCode=from_stn,toStnCode=to_stn,date=date,pnr=pnr,age=age)
    details.save()
    return render(request,"pnr.html",{'details':details})

def search(request):
    if request.method=="POST":
        pnr = request.POST.get('pnr')

    details=ticket_details.objects.filter(pnr=pnr)
    print(details)
    if details:
        return render(request, "search.html", {'details': details})
    else:
        print('no user exist')
        messages.error(request, 'Invalid PNR Number!! Please try again')
        return redirect("/index")

def cancel(request):
    if request.method=="POST":
        pnr = request.POST.get('pnr')

    details=ticket_details.objects.filter(pnr=pnr)
    details.delete()
    return render(request,'cancel1.html')