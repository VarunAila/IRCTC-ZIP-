from django.db import models

# Create your models here.
class train_details(models.Model):
    trainName = models.CharField(max_length=200)
    trainNumber = models.CharField(max_length=200)
    fromStnCode = models.CharField(max_length=200)
    toStnCode = models.CharField(max_length=200)
    departureTime = models.CharField(max_length=200)
    arrivalTime = models.CharField(max_length=200)
    duration = models.CharField(max_length=200)
    arrivaldate = models.DateField(null=True)
    date=models.DateField(null=True)
    avlClasses = models.CharField(max_length=200)
    days=models.CharField(max_length=200)
    second_sitting=models.CharField(max_length=200)
    sleeper_class=models.CharField(max_length=200)
    AC_threetier=models.CharField(max_length=200)
    AC_twotier=models.CharField(max_length=200)
    AC_onetier=models.CharField(max_length=200)

class login_details(models.Model):
    username=models.CharField(max_length=200)
    password=models.CharField(max_length=200)
    first_name=models.CharField(max_length=200)
    last_name=models.CharField(max_length=200)
    email=models.EmailField(max_length=200)
    date_of_birth=models.DateTimeField(null=True)
    gender = models.CharField(max_length=10)
    phone_no = models.CharField(max_length=200)
    city=models.CharField(max_length=200)
    state=models.CharField(max_length=200)


class ticket_details(models.Model):
    name=models.CharField(max_length=200)
    phone_no=models.CharField(max_length=200)
    fromStnCode = models.CharField(max_length=200)
    toStnCode = models.CharField(max_length=200)
    date=models.CharField(max_length=200)
    pnr=models.CharField(max_length=200)
    age=models.CharField(max_length=200)













